sap.ui.controller("tcs.Comp.controller.Course", {


	onInit: function() {
		
	},
	tilePress : function(oEvent) {
		var courseId = oEvent.getSource().getSubheader();
		this.getOwnerComponent().getRouter().navTo("master", { cid : courseId});
	}


});