sap.ui.controller("tcs.oc.Comp.controller.ProductList", {
onInit : function(){
	this.getView().byId("idList").attachUpdateFinished(function(){
		
		this.getView().byId("idList").getItems()[0].firePress();
	},this);
},
onItemSelection : function(oEvent){
//	this.getOwnerComponent().getRouter().navTo("pdetail");
	debugger;
	var productId = oEvent.getSource().getTitle();
	this.getOwnerComponent().getRouter().navTo("pdetail", { prdId : productId });
}

});