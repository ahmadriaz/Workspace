sap.ui.controller("tcs.Comp.controller.Course", {


	onInit: function() {
		
	},
	tilePress : function(oEvent) {
		var courseId = oEvent.getSource().getSubheader();
		this.getOwnerComponent().getRouter().navTo("master", { cid : courseId});
	},
	createCourse : function(){
		// dialog

		var odialog = new sap.m.Dialog({
			title : "Create Course",
			content : [

				new sap.m.Label({ text : "Course ID"}),
				new sap.m.Input(),
				new sap.m.Label({ text : "Course Name"}),
				new sap.m.Input(),
				new sap.m.Label({ text : "Duration"}),
				new sap.m.Input(),
				new sap.m.Label({ text : "Trainer"}),
				new sap.m.Input(),
				new sap.m.Label({ text : "Pre-Requisite"}),
				new sap.m.Input(),
				new sap.m.Label({ text : "Mode"}),
				new sap.m.Input()
				],
				buttons : [
					new sap.m.Button({ text : "Create and close", press : function(oEvent){
						//save the data in SAP
						var oModel = oEvent.getSource().getParent().getModel();

						var data = {
								Courseid : oEvent.getSource().getParent().getContent()[1].getValue(),
								Cname : oEvent.getSource().getParent().getContent()[3].getValue(),
								Duration :oEvent.getSource().getParent().getContent()[5].getValue(),
								Trainer :oEvent.getSource().getParent().getContent()[7].getValue(),
								Pre :oEvent.getSource().getParent().getContent()[9].getValue(),
								Zmode:oEvent.getSource().getParent().getContent()[11].getValue()

						}

						oModel.create("/courseSet", data, { 
							success : function(){
								sap.m.MessageToast.show("Data created");
							}, 
							error : function(){
								sap.m.MessageToast.show("Data not  created");
							}

						});


						oEvent.getSource().getParent().close();

					}}),
					new sap.m.Button({ text : "Close", press : function(oEvent){
						oEvent.getSource().getParent().close();
					} })
					]
		});
		odialog.setModel(this.getOwnerComponent().getModel());
		odialog.open();
	},
	updateCourse : function(){
		// update name of the product
		// prodID, name
//		var prodID = this.getView().byId("idprodID").getText();
//		var productName = this.getView().byId("idprodName").getText();

		var odialog = new sap.m.Dialog({
			title : "Update Course Details",
			content : [
				new sap.m.Label({ text : "Course ID"}),
//				new sap.m.Input(),
				new sap.m.ComboBox({ 
					items : [
						new sap.ui.core.Item({ text : "{Courseid}"})
					]
				}),
				new sap.m.Label({ text : "Course Name"}),
				new sap.m.Input(),
				new sap.m.Label({ text : "Duration"}),
				new sap.m.Input(),
				new sap.m.Label({ text : "Trainer"}),
				new sap.m.Input(),
				new sap.m.Label({ text : "Pre-Requisite"}),
				new sap.m.Input(),
				new sap.m.Label({ text : "Mode"}),
				new sap.m.Input()
				],
				buttons : [
					new sap.m.Button({ text : "Update and Close", press : function(oEvent){
						//Update
						var oModel = oEvent.getSource().getParent().getModel();
//						var crid = oEvent.getSource().getParent().getContent()[1].getValue();
						var crid = oEvent.getSource().getParent().getContent()[1].getSelectedItem().getText();
						var data = {
								Courseid : oEvent.getSource().getParent().getContent()[1].getValue(),
								Cname : oEvent.getSource().getParent().getContent()[3].getValue(),
								Duration :oEvent.getSource().getParent().getContent()[5].getValue(),
								Trainer :oEvent.getSource().getParent().getContent()[7].getValue(),
								Pre :oEvent.getSource().getParent().getContent()[9].getValue(),
								Zmode:oEvent.getSource().getParent().getContent()[11].getValue() 
						}

						oModel.update("/courseSet('"+crid+"')", data, {
							success : function(){
								sap.m.MessageToast.show("Course Updated");
							},
							error : function(){
								sap.m.MessageToast.show("Course Not Updated");
							}
						})


						//close
						oEvent.getSource().getParent().close();
					}}),

					new sap.m.Button({ text : "Close", press : function(oEvent){
						oEvent.getSource().getParent().close();
					}})
					]
		});

		odialog.setModel(this.getOwnerComponent().getModel());
		
		var combo = odialog.getContent()[1];
		combo.bindAggregation("items", "/courseSet", new sap.ui.core.Item({ text : "{Courseid}"}));
		odialog.open();


	},
	deleteCourse : function(){

		var oModel = this.getOwnerComponent().getModel();
		
		var odialog = new sap.m.Dialog({
			title : "Delete Course",
			content : [
				new sap.m.Label({ text : "Course ID"}),
				new sap.m.ComboBox({ 
					items : [
						new sap.ui.core.Item({ text : "{Courseid}"})
					]
				})
//				new sap.m.Input(),
				],
				buttons : [
					new sap.m.Button({ text : "Delete and Close", press : function(oEvent){
						//Update
						var oModel = oEvent.getSource().getParent().getModel();
						//var crid = oEvent.getSource().getParent().getContent()[1].getValue();
						var crid = oEvent.getSource().getParent().getContent()[1].getSelectedItem().getText();
						
						oModel.remove("/courseSet('"+crid+"')", {
							success : function(){ sap.m.MessageToast.show("Course Deleted"); },
							error : function(){ sap.m.MessageToast.show("Course not Deleted"); }
						})
						
						//close
						oEvent.getSource().getParent().close();
					}}),

					new sap.m.Button({ text : "Close", press : function(oEvent){
						oEvent.getSource().getParent().close();
					}})
					]
		});
		odialog.setModel(this.getOwnerComponent().getModel());
		
		var combo = odialog.getContent()[1];
		combo.bindAggregation("items", "/courseSet", new sap.ui.core.Item({ text : "{Courseid}"}));
		
		odialog.open();
	}
});