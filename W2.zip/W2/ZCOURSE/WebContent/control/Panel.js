sap.ui.define(
    ['sap/m/Panel'],
    function(Panel) {
        return Panel.extend("tcs.Comp.control.Panel",{
            metadata: {
                properties: {
                    val: {
                        type: "boolean",
                        defaultValue: true
                    }
                }
            },
            renderer: function(oRm,oControl){
                sap.m.PanelRenderer.render(oRm,oControl); //use supercass renderer routine
//            	sap.ui.commons.TextFieldRenderer.render(oRm, oControl);
            },
        });
    }
);