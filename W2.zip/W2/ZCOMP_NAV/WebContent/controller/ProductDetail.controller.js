sap.ui.controller("tcs.oc.Comp.controller.ProductDetail", {

	onInit : function(){
		var router = this.getOwnerComponent().getRouter();
		debugger;
		router.getRoute("pdetail").attachPatternMatched(function(oEvent){
			var prodId = oEvent.getParameters().arguments.prdId;
			this.getView().byId("xyz").bindElement("/ProductSet('"+prodId+"')");
		},this);
	}

});