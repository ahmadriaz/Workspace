sap.ui.controller("tcs.oc.Comp.controller.ProductList", {

onItemSelection : function(oEvent){
//	this.getOwnerComponent().getRouter().navTo("pdetail");
	debugger;
	var productId = oEvent.getSource().getTitle();
	this.getOwnerComponent().getRouter().navTo("pdetail", { prdId : productId });
}

});