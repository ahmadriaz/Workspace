sap.ui.controller("view.MyPage", {
	
	
	//code where you can control the view
	onInit : function(){
		var oInput = this.getView().byId("idip");
		oInput.setValue("Surender");
		
		var eRole = this.getView().byId("idRole");
		eRole.setText("Marketing Agent");
	}
}


);
